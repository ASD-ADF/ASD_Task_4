#include "list.h"

void createList(List &L) {
    /**
    * FS : first(L) diset Nil
    */
    //-------------your code here-------------

    first(L) = NULL;
    //----------------------------------------
}

address alokasi(infotype x) {
    /**
    * FS : mengembalikan elemen list baru dengan info = x, next elemen = Nil
    */

    address P;
    //-------------your code here-------------
    address(p) = new elmlist;
    info(P) = x;
    next(P) = NULL;
    //----------------------------------------
    return P;
}

void dealokasi(address &P) {
    /**
    * FS : menghapus elemen yang ditunjuk oleh P (delete)
    */
    //-------------your code here-------------
    delete(P);

    //----------------------------------------
}

void insertFirst(List &L, address P) {
    /**
    * IS : List L mungkin kosong
    * FS : elemen yang ditunjuk P menjadi elemen pertama pada List L
    */
    //-------------your code here-------------

    if (first(L)==NULL){
        P = first(L);
        next(last(L)) = first(L);
        prev(first(L)) = last(L);
    }
    else{
        next(P) = first(L);
        first(L) = P;
        next(last(L)) = first(L);
        prev(first(L)) = last(L);

    //----------------------------------------
}

void insertLast(List &L, address P) {
    /**
    * IS : List L mungkin kosong
    * FS : elemen yang ditunjuk P menjadi elemen terakhir pada List L
    */
    //-------------your code here-------------
    if (last(L) == NULL){
        P = last(L);
        next(last(L)) = first(L);
        prev(first(L)) = last(L);
    }
    else{
        next(P) = last(L);
        last(L) = P;
        next(last(L)) = first(L);
        prev(first(L)) = last(L);
    }

    //----------------------------------------
}

address findElm(List L, infotype x) {
    /**
    * IS : List L mungkin kosong
    * FS : mengembalikan elemen dengan info.ID = x.ID,
           mengembalikan Nil jika tidak ditemukan
    */

    address P;
    //-------------your code here-------------
    do
    if (info(P) == x){
        return P;
    }
    P = next(P);

    while(P != first(L));
    return NULL;

    //----------------------------------------
    return P;
}

void deleteFirst(List &L, address &P) {
    /**
    * IS : List L mungkin kosong
    * FS : elemen pertama di dalam List L dilepas dan disimpan/ditunjuk oleh P
    */
    //-------------your code here-------------
     P = first(L);

     if (p != NULL){
        if(first(L) == NULL){
            first(L) = NULL;
            last(L) = NULL;

            next(last(L)) = first(L);
            prev(first(L)) = last(L);
        }
        else{
            P = first(L);
            next(P) = first(L);
            dealokasi(P);

            next(last(L)) = first(L);
            prev(first(L)) = last(L);
        }
     }

    //----------------------------------------
}

void deleteLast(List &L, address &P) {
    /**
    * IS : List L mungkin kosong
    * FS : elemen tarakhir di dalam List L dilepas dan disimpan/ditunjuk oleh P
    */
    //-------------your code here-------------
    P = last(L);

    if (last(L)==NULL){
        first(L) = NULL;
        last(L) = NULL;

        next(last(L)) = first(L);
        prev(first(L)) = last(L);
    }
    else{
        P = last(L);
        prev(P) = last(L);
        dealokasi(P);

        next(last(L)) = first(L);
        prev(first(L)) = last(L);
    }

    //----------------------------------------
}

void insertAfter(address Prec, address P) {
    /**
    * IS : Prec dan P tidak NULL
    * FS : elemen yang ditunjuk P menjadi elemen di belakang elemen yang
    *      ditunjuk pointer Prec
    */
    //-------------your code here-------------
    P = alokasi(x);
    next(P) = NULL;
    prev(P) = NULL;

    next(P) = next(Prec);
    prev(P) = Prec;
    prev(next(Prec)) = P;
    next(Prec) = P;

    //----------------------------------------

}
void deleteAfter(address Prec, address &P) {
    /**
    * IS : Prec tidak NULL
    * FS : elemen yang berada di belakang elemen Prec dilepas
    *      dan disimpan/ditunjuk oleh P
    */
    //-------------your code here-------------
    prev(next(P)) = Prec;
    next(Prec) = next(P);
    dealokasi(P);

    //----------------------------------------
}

